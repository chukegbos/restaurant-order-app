<?php $__env->startSection('pageTitle', 'Outlets'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>All Outlets</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Outletss</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">
                <a class="btn btn-success btn-xs" href="#" data-toggle="modal" data-target="#addbar"> 
                  <i class="fa fa-plus"></i> Add Outlets
                </a>  
              </h3>
            </div>
            <?php if(isset($status)): ?>
              <div class="alert alert-success alert-dismissable" style="margin:20px">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4>  <i class="icon fa fa-check"></i> Success!</h4>
                <?php echo e($status); ?>

              </div>
            <?php endif; ?>

            <?php if(isset($error)): ?>
              <div class="alert alert-danger alert-dismissable" style="margin:20px">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4>  <i class="icon fa fa-times"></i> Oops!</h4>
                  <?php echo e($error); ?>

              </div>
            <?php endif; ?>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>Outlet Name</th>
                      <th>Outlets ID</th>
                      <th>Current Manager</th>
                      <th>Action</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($bar->bar_name); ?></td>
                        <td><?php echo e($bar->bar_id); ?></td>
                        <td>
                          <?php if(isset($bar->current_manager)): ?>
                            <?php $__empty_2 = true; $__currentLoopData = $theusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            
                              <?php if($user->id==$bar->current_manager): ?>
                              <?php echo e($user->name); ?>

                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <?php endif; ?>
                          <?php else: ?>
                            No Attendant
                          <?php endif; ?>
                        </td>
                        <th>
                          <a class="btn btn-success btn-xs" href="#" data-toggle="modal" data-target="#editbar<?php echo e($bar->id); ?>"><i class="fa fa-edit"></i> Edit</a> 
                          <a href="<?php echo e(url('/store')); ?>/?bar_id=<?php echo e($bar->bar_id); ?>" class="btn btn-info btn-xs">Inventory</a>
                          <a href="<?php echo e(url('/orders')); ?>/?barid=<?php echo e($bar->id); ?>" class="btn btn-warning btn-xs">Sales</a>
                        </th>

                        <td>
                          <form action="<?php echo e(url('/deletebar')); ?>/<?php echo e($bar->id); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(Method_field('DELETE')); ?>

                            
                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                          </form>
                        </td>
                      </tr>


                      <div class="modal fade" id="editbar<?php echo e($bar->id); ?>">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Edit Outlet</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <form class="col-sm-12" method="POST" action="<?php echo e(url('/updatebar')); ?>">
                                  <?php echo e(csrf_field()); ?>

                                  <div class="form-group">
                                    <label>Name of Bar</label>
                                    <input type="text" class="form-control" name="bar_name" required value="<?php echo e($bar->bar_name); ?>">
                                  </div>

                                  <div class="form-group">
                                    <label>Bar ID</label>
                                    <input type="text" class="form-control" name="bar_id" value="<?php echo e($bar->bar_id); ?>" readonly="true">
                                  </div>
                                  <div class="reset button">
                                    <button type="submit" class="btn btn-success">Save</button>
                                  </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!-- /.col -->
      </div>
    </section>
    <!-- /.content -->
  </div>

  <div class="modal fade" id="addbar">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Add Outlet</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form class="col-sm-12" method="POST" action="<?php echo e(url('/bar')); ?>">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label>Name of Outlet</label>
                <input type="text" class="form-control" name="bar_name" required>
              </div>

              <div class="form-group">
                <label>Outlet ID</label>
                <input type="text" class="form-control" name="bar_id" value="<?php echo e($random_number); ?>" readonly="true">
              </div>

              <div class="reset button">
                <button type="submit" class="btn btn-success">Save</button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>