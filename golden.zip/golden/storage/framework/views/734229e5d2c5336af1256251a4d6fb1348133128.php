<?php $__env->startSection('pageTitle', 'Payment'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-container">   
  <div class="page-content-wrapper">
    <section class="section-reservation-form" style="padding: 20px">
      <div class="container">
        <div class="section-content">
          <div class="swin-sc swin-sc-title style-2">
            <h3 class="title"><span>Payment</span></h3>
          </div>
          
          <div class="row">
            <div class="col-md-12"> 
              <?php echo $__env->make('component.usersidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
              <div class="content">
                <div class="row">
                  <div class="col-md-3"> </div>
                  <div class="col-md-6"> 
                    <div class="swin-sc swin-sc-contact-form light mtl">
                      <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                          <thead>
                            <tr>
                              <th>Product</th>
                              <th>Quantity</th>
                              <th>Unit Price (<span>&#8358;</span>)</th>
                              <th>Price (<span>&#8358;</span>)</th>
                            </tr>
                          </thead>

                          <tbody>
                            <?php $__currentLoopData = $orderss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($item['item']['stock_name']); ?></td>
                                <td><?php echo e($item['quantity']); ?></td>
                                <td><?php echo e($item['selling_price'] / $item['quantity']); ?></td>
                                <td><?php echo e($item['selling_price']); ?></td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>

                          <tfoot>
                            <tr>
                              <th></th>
                              <th></th>
                              <th></th>
                              <th></th>
                            </tr>

                            <tr>
                              <th></th>
                              <th class="text-right  pd-10"></th>
                              <th class="text-center  pd-10">Total Price</th>
                              <th class="text-center  pd-10 "><span class="vd_green font-sm font-normal"><span>&#8358;</span><?php echo e($totalPrice); ?></span></th>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    
                      <p style="text-align: center;">
                        <?php $__currentLoopData = $theusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($user->id==$orders->buyer): ?>
                            Name: <span style="font-weight: bolder"><?php echo e($user->name); ?></span> <br>
                            Phone: <span style="font-weight: bolder"><?php echo e($user->phone); ?></span> <br>
                            Email: <span style="font-weight: bolder"><?php echo e($user->email); ?></span><br>
                            Delivery Address: <span style="font-weight: bolder"><?php echo e($delivery_address); ?></span><br>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--Mode of Payment: <span style="font-weight: bolder"><?php echo e($orders->mop); ?></span> <br>
                        Date of Payment: <span style="font-weight: bolder"><?php echo e($orders->created_at->toFormattedDateString()); ?></span><br>-->
                      </p>
                      <?php if($payment_status!="Paid"): ?>
                        <div class="row">
                          <div class="col-md-4"></div>
                          <div class="col-md-2">
                            <form>
                              <script src="https://js.paystack.co/v1/inline.js"></script>
                              <button type="button" onclick="payWithPaystack()" class="btn btn-success pull-right">Pay</button> 
                            </form>
                          </div>
                        </div>
                      <?php else: ?>
                      <p style="text-align: center;">
                        Payment Status: <span style="font-weight: bolder"><?php echo e($payment_status); ?></span> <br>
                        Delivery Status: <span style="font-weight: bolder"><?php echo e($delivery_status); ?></span> <br>
                      </p>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

<script>
  function payWithPaystack(){
    var handler = PaystackPop.setup({
      key: 'pk_test_15bebc3c7d43577a794d37b53b2b04417f70c908',
      email: '<?php echo e($iuser->email); ?>',
      amount: '<?php echo e($totalPrice); ?>00',
      currency: "NGN",
      phone: "<?php echo e($iuser->phone); ?>",
      firstname: '<?php echo e($iuser->name); ?>',
      custom_description: "Golden Apple Restuarant Order",
      description: "Golden Apple Restuarant Order",
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      metadata: {
         custom_fields: [
            {
                display_name: "<?php echo e($iuser->name); ?>",
                variable_name: "<?php echo e($iuser->name); ?>",
                value: "<?php echo e($iuser->phone); ?>"
            }
         ]
      },
      callback: function(response){
           window.location.replace("<?php echo e(url('/shoppingcart2')); ?>/?payment_id=<?php echo e($sale_id); ?>");
          //alert('success. transaction ref is ' + response.reference);
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>