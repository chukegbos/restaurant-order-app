<?php $__env->startSection('pageTitle', 'Meal'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Meals</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Meals</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">
                <a class="btn btn-success btn-xs" href="#" data-toggle="modal" data-target="#addproduct"> 
                  <i class="fa fa-plus"></i> Add Meal
                </a>  
              </h3>
            </div>
            <?php if(isset($status)): ?>
              <div class="alert alert-success alert-dismissable" style="margin:20px">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4>  <i class="icon fa fa-check"></i> Success!</h4>
                <?php echo e($status); ?>

              </div>
            <?php endif; ?>

            <?php if(isset($error)): ?>
              <div class="alert alert-danger alert-dismissable" style="margin:20px">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4>  <i class="icon fa fa-times"></i> Oops!</h4>
                  <?php echo e($error); ?>

              </div>
            <?php endif; ?>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>Meal ID</th>
                      <th>Meal Name</th>
                      <th>Featured Image</th>
                      <th>Category</th>
                      <th>Price(<span>&#8358;</span>)</th>
                      <th>Action</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($product->stock_id); ?></td>
                        <td><?php echo e($product->stock_name); ?></td>
                        <td><img src="<?php echo e(asset('storage')); ?>/<?php echo e($product->image); ?>" class="center img-responsive img-fluid" style="height: 70px; width: 70px"></td>
                        <td>
                          <?php if($product->category=="General"): ?>
                            General
                          <?php else: ?>
                            <?php $__empty_2 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                              <?php if($category->id==$product->category): ?>
                                <?php echo e($category->name); ?>

                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <?php endif; ?>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($product->selling_price); ?></td>
                        <th>
                          <a class="btn btn-warning btn-xs" href="#" data-toggle="modal" data-target="#editproduct<?php echo e($product->id); ?>"><i class="fa fa-edit"></i> Edit</a> 
                          
                          <a href="<?php echo e(url('/addcart')); ?>/<?php echo e($product->id); ?>" class="btn btn-info btn-xs">Add to Cart</a>
                        </th>

                        <td>
                          <form action="<?php echo e(url('/deleteproduct')); ?>/<?php echo e($product->id); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(Method_field('DELETE')); ?>

                            
                            <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                          </form>
                        </td>
                      </tr>


                      <div class="modal fade" id="editproduct<?php echo e($product->id); ?>">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Edit Meal</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <form class="col-sm-12" method="POST" action="<?php echo e(url('/updateproduct')); ?>" enctype="multipart/form-data">
                                  <?php echo e(csrf_field()); ?>

                                  <div class="form-group">
                                    <label>Name of Meal</label>
                                    <input type="text" class="form-control" name="stock_name" required value="<?php echo e($product->stock_name); ?>">
                                  </div>

                                  <div class="form-group">
                                    <label>Meal ID</label>
                                    <input type="text" class="form-control" name="stock_id" value="<?php echo e($product->stock_id); ?>" readonly="true">
                                  </div>

                                  <div class="form-group">
                                    <label>Category</label>
                                    <select class="form-control" name="category">
                                        <option value="General">General</option>
                                      <?php $__empty_2 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <option value="<?php echo e($category->id); ?>"  <?php if($product->category==$category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                      <?php endif; ?>
                                    </select>
                                  </div>
                                  <!--<div class="form-group">
                                    <label>Cost Price (<span>&#8358;</span>)</label>
                                    <input type="number" class="form-control" name="cost_price" required="" value="<?php echo e($product->cost_price); ?>">
                                  </div>-->

                                  <div class="form-group">
                                    <label>Selling Price (<span>&#8358;</span>)</label>
                                    <input type="number" class="form-control" name="selling_price" value="<?php echo e($product->selling_price); ?>" required="">
                                  </div>

                                  <div class="form-group">
                                    <label>Featured Image</label>
                                    <input type="file" class="form-control" name="image">
                                  </div>

                                  <div class="reset button">
                                    <button type="submit" class="btn btn-success">Save</button>
                                  </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!-- /.col -->
      </div>
    </section>
    <!-- /.content -->
  </div>

  <div class="modal fade" id="addproduct">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Add Meal</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form class="col-sm-12" method="POST" action="<?php echo e(url('/product')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label>Name of Meal</label>
                <input type="text" class="form-control" name="stock_name" required>
              </div>

              <div class="form-group">
                <label>Meal ID</label>
                <input type="text" class="form-control" name="stock_id" value="<?php echo e($random_number); ?>" readonly="true">
              </div>

              <div class="form-group">
                <label>Category</label>
                <select class="form-control" name="category">
                    <option selected="" value="General">General</option>
                  <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <?php endif; ?>
                </select>
              </div>
              <!--<div class="form-group">
                <label>Cost Price (<span>&#8358;</span>)</label>
                <input type="number" class="form-control" name="cost_price" required="">
              </div>-->

              <div class="form-group">
                <label>Selling Price (<span>&#8358;</span>)</label>
                <input type="number" class="form-control" name="selling_price" required="">
              </div>

              <div class="form-group">
                <label>Featured Image</label>
                <input type="file" class="form-control" name="image" required="">
              </div>


              <div class="reset button">
                <button type="submit" class="btn btn-success">Save</button>
              </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>