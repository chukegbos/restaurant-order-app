<?php $__env->startSection('pageTitle', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
    @media  screen and (min-width: 800px) {
      .set {
       margin-top: 50px
      }
    }
</style>
<div class="page-container">
  <div class="page-content-wrapper set">
    <section class="product-sesction-02 padding-top-120 padding-bottom-100">
        <div class="container">
          <div class="swin-sc swin-sc-title">
            <p class="top-title"><span>Popular Product</span></p>
            <h3 class="title">Tasty And Good Price</h3>
          </div>
          <div class="swin-sc swin-sc-product products-02">
            <div class="products nav-slider">
              <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $allproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="col-md-3 col-sm-6 col-xs-12">
                      <div class="blog-item item swin-transition">
                          <div class="block-img">
                              <img src="<?php echo e(asset('storage')); ?>/<?php echo e($product->image); ?>" alt="" class="img img-responsive" style="height: 180px">
                              <div class="block-circle price-wrapper">
                                  <span class="price woocommerce-Price-amount amount">
                                      <span class="price-symbol"><span>&#8358;</span></span><?php echo e($product->selling_price); ?>

                                  </span>
                              </div>
                              <div class="group-btn">
                                  <a href="<?php echo e(url('/addcart')); ?>/<?php echo e($product->id); ?>" class="swin-btn btn-add-to-card">
                                      <i class="fa fa-shopping-basket"></i>
                                  </a>
                              </div>
                          </div>
                          <div class="block-content">
                              <h5 class="title">
                                  <?php echo e($product->stock_name); ?>

                              </h5>
                              <div class="product-info">
                                  <ul class="list-inline">
                                      <li class="author">
                                          <a href="<?php echo e(url('/addcart')); ?>/<?php echo e($product->id); ?>">
                                              <i class="fa fa-shopping-basket"></i>
                                              <span>Order</span>
                                          </a>
                                      </li>

                                      <li>
                                          <a href="<?php echo e(url('/addcart')); ?>/<?php echo e($product->id); ?>">
                                              <span class="price-symbol"><span>&#8358;</span></span><?php echo e($product->selling_price); ?>

                                          </a>
                                      </li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
              </div>
            </div>
            <div class="row">
                <div class="col">
                  <ul class="pagination float-right">
                      <?php echo e($theproducts->links()); ?>

                  </ul>
                </div>
              </div>
          </div>
        </div>
    </section>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>