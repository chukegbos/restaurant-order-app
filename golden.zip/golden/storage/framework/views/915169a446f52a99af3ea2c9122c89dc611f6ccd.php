<?php $__env->startSection('pageTitle', 'My Orders'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-container">   
  <div class="page-content-wrapper">
    <section class="section-reservation-form" style="padding: 20px">
      <div class="container">
        <div class="section-content">
          <div class="swin-sc swin-sc-title style-2">
            <h3 class="title"><span>My Orders</span></h3>
          </div>
          <div class="row">
            <div class="col-md-12"> 
              <?php echo $__env->make('component.usersidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
              <div class="content">
                <div class="swin-sc swin-sc-contact-form light mtl" style="padding: 30px">
                  
                  <div class="table-responsive">
                    <table id="example2" class="table table-bordered table-hover">
                      <thead>
                        <tr>
                          <th>Sale ID</th>
                          <th>Total Price (Naira)</th>
                          <th>Payment Status</th>
                          <th>Order Status</th>
                          <th>Date</th>
                          <th>Action</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($order->sale_id); ?></td>
                          <td>N<?php echo e($order->cart->totalPrice); ?></td>  
                          <td><?php echo e($order->payment_status); ?></td>
                          <td><?php echo e($order->delivery_status); ?>

                              <form action="<?php echo e(url('/changestatus')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                <select name="delivery_status" onchange='form.submit()'>
                                  <option>---</option>
                                  <option value="Completed">Completed</option>
                                  <option value="Cancelled">Cancelled</option>
                                </select>
                              </form>
                          </td>
                          <td><?php echo e($order->created_at->toFormattedDateString()); ?></td>
                          <td><a href="<?php echo e(url('/shoppingcart2')); ?>/?payment_id=<?php echo e($order->sale_id); ?>" class="btn btn-success"><?php if($order->payment_status=="Paid"): ?>View <?php else: ?> View/Pay <?php endif; ?></a></td>                 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                      </tbody>                     
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>       
        </div>
      </div>
    </section>  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>