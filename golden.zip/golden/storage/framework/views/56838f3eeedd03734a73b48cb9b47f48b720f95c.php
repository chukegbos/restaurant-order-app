<?php $__env->startSection('pageTitle', 'Sales'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Sales</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Sales</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <?php if(isset($status)): ?>
              <div class="alert alert-success alert-dismissable" style="margin:20px">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4>  <i class="icon fa fa-check"></i> Success!</h4>
                <?php echo e($status); ?>

              </div>
            <?php endif; ?>

            <?php if(isset($error)): ?>
              <div class="alert alert-danger alert-dismissable" style="margin:20px">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4>  <i class="icon fa fa-times"></i> Oops!</h4>
                  <?php echo e($error); ?>

              </div>
            <?php endif; ?>
            <!-- /.card-header -->
            <div class="card-body">
              <div class="table-responsive">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>Sale ID</th>
                      <th>Buyer</th>
                      <th>Total Price (Naira)</th>
                      <th>Payment Staus</th>
                      <th>Status</th>
                      <th>Date</th>
                      <th>Action</th>
                      
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($order->sale_id); ?></td>
                      <td><?php $__empty_2 = true; $__currentLoopData = $theusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                          <?php if($user->id==$order->buyer): ?>
                          <?php echo e($user->name); ?>

                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <?php endif; ?>
                      </td>
                      <td>N<?php echo e($order->cart->totalPrice); ?></td>  
                      <td>
                        <?php if($order->payment_status=="Paid"): ?> <span style="color: green">Paid </span> <?php else: ?> <span style="color: red"> Unpaid </span> <?php endif; ?>
                      </td>

                      <td>
                        <?php echo e($order->delivery_status); ?>

                        <form action="<?php echo e(url('/changestatus')); ?>" method="post">
                          <?php echo e(csrf_field()); ?>

                          <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                          <select name="delivery_status" onchange='form.submit()'>
                            <option value="Pending">Pending</option>
                            <option value="In-progress">In-progress</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Completed">Completed</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </form>
                      </td>
                      <td><?php echo e($order->created_at->toFormattedDateString()); ?></td>
                      <td><a href="<?php echo e(url('/vieworders')); ?>/?pid=<?php echo e($order->sale_id); ?>" class="btn btn-success">View</a></td>                 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                  </tbody>                     
                </table>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
        <!-- /.col -->
      </div>
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>