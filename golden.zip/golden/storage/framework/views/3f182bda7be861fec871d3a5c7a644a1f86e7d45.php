<style type="text/css">
  .nav-item
  {
    font-size: 15px;
    color: #f0c332
  }

  .nav-link
  {
    color: #f0c332
  }
</style>      
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="<?php echo e(url('/')); ?>">
    <img src="<?php echo e(asset('storage')); ?>/<?php echo e($setting->logo); ?>" class="brand-image img-circle elevation-3 img-responsive img-fluid" style="opacity: .9; height: 100px; width: 200px">
    <!--<span class="brand-text font-weight-light"><?php echo e($setting->sitename); ?></span>-->
  </a>
  <hr style="color: #f0c332">
  <div class="sidebar">
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a  class="nav-link" href="<?php echo e(url('/dashboard')); ?>" style="color: #f0c332;">
            <i class="nav-icon fa fa-home"></i>
            <p  style="color: #fff;">
              Dashboard
            </p>
          </a>
        </li>

        <?php if(Auth::user()->role=="Attendant"): ?>
          <li class="nav-item">
            <a href="<?php echo e(url('/store')); ?>/?bar=bar" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-beer"></i>
              <p  style="color: #fff;">
                Inventory
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/orders')); ?>/?attendant=attendant" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-cart-arrow-down"></i>
              <p  style="color: #fff;">
                Sales Report
              </p>
            </a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a href="<?php echo e(url('/bar')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-beer"></i>
              <p  style="color: #fff;">
                Outlets
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/category')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-box"></i>
              <p  style="color: #fff;">
                Categories
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/product')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-credit-card"></i>
              <p  style="color: #fff;">
                Menu
              </p>
            </a>
          </li>

          <!--<li class="nav-item">
            <a href="<?php echo e(url('/supplier')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-biking"></i>
              <p  style="color: #fff;">
                Suppliers
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/purchase')); ?>/?debt=debt" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-clock"></i>
              <p  style="color: #fff;">
                Suppliers' Debt
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/purchase')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-address-book"></i>
              <p  style="color: #fff;">
                Purchase Report
              </p>
            </a>
          </li>-->

          <li class="nav-item">
            <a href="<?php echo e(url('/orders')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-cart-arrow-down"></i>
              <p  style="color: #fff;">
                Sales Report
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(url('/attendants')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-users"></i>
              <p  style="color: #fff;">
                Staff
              </p>
            </a>
          </li>
        <?php endif; ?>

        <!--<li class="nav-item">
            <a href="" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-user"></i>
              <p  style="color: #fff;">
                Profile
              </p>
            </a>
          </li>-->
          
          <li class="nav-item">
            <a href="<?php echo e(url('/password')); ?>" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fa fa-key"></i>
              <p  style="color: #fff;">
                Change Password
              </p>
            </a>
          </li>

        <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav-link" style="color: #f0c332;">
              <i class="nav-icon fas fa-lock"></i>
              <p  style="color: #fff;">Logout</p>        
          </a>
          <form id="logout-form" action="<?php echo e(url('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

          </form>
        </li>
      </ul>
    </nav>
  </div>
</aside>